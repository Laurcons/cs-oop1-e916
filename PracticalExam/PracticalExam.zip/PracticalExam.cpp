#include "PracticalExam.h"

PracticalExam::PracticalExam(QWidget *parent)
    : QMainWindow(parent)
{
    ui.setupUi(this);
}
